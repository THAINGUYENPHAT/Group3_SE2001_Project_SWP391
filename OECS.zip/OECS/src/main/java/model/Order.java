package model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Order {

    private int orderId, userId, addressId;
    private String orderStatus, paymentMethod, paymentStatus;
    private String recipientName, recipientPhone, shippingAddress;
    private BigDecimal totalAmount, shippingFee, discountAmount;
    private Timestamp createdAt, paymentExpiresAt;

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int v) {
        orderId = v;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int v) {
        userId = v;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int v) {
        addressId = v;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String v) {
        orderStatus = v;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String v) {
        paymentMethod = v;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String v) {
        paymentStatus = v;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public void setRecipientName(String v) {
        recipientName = v;
    }

    public String getRecipientPhone() {
        return recipientPhone;
    }

    public void setRecipientPhone(String v) {
        recipientPhone = v;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String v) {
        shippingAddress = v;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal v) {
        totalAmount = v;
    }

    public BigDecimal getShippingFee() {
        return shippingFee;
    }

    public void setShippingFee(BigDecimal v) {
        shippingFee = v;
    }

    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(BigDecimal v) {
        discountAmount = v;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp v) {
        createdAt = v;
    }

    public Timestamp getPaymentExpiresAt() {
        return paymentExpiresAt;
    }

    public void setPaymentExpiresAt(Timestamp v) {
        paymentExpiresAt = v;
    }
}
